
<div class="content py-3">
    
    <div class="card-body rounded-0">
        <h2 class="text-center">Liên hệ</h2>
        <center><hr class="bg-navy border-navy w-25 border-2"></center>
        <div>
            <?= file_get_contents("lien-he.html") ?>
        </div>
    </div>
    
</div>